WinPmem Installation Instructions
==================================

WinPmem is required for memory acquisition functionality.

DOWNLOAD:
1. Visit: https://github.com/Velocidex/WinPmem/releases
2. Download the latest winpmem_mini_x64.exe
3. Rename it to winpmem.exe
4. Place it in this folder

After installation:
- Restart WinScope
- The Memory Collection module will be enabled

